REQUIRES:
nltk
numpy
random
pickle
sklearn
statistics
dbAccesser

If you run in command line call sentiment("inputstring") and the classifier will make its best guess at your sentiment
