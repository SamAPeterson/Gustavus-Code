import sqlite3
import numpy as np
import subprocess


def get_tweets():
	db = sqlite3.connect('tweets.db')

	cursor = db.cursor()
	cursor.execute('SELECT DISTINCT tweet FROM betterTweets WHERE movie = 3;')
	tweets = np.random.choice(np.array([i[0] for i in cursor.fetchall()]), 1000)

	return tweets



